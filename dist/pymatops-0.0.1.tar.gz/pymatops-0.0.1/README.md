# pymatops
A Python package for Matrix Operations
